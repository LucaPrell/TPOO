/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function Sposta() {
    let nome1 = document.getElementById("ins_nome1").value;
    let nome2 = document.getElementById("ins_nome2").value;
    let nome3 = document.getElementById("ins_nome3").value;

    document.getElementById("ins_nome1").value = nome3;
    document.getElementById("ins_nome2").value = nome1;
    document.getElementById("ins_nome3").value = nome2;
}


