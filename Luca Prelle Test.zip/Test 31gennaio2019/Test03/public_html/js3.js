/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var ar_acquisto = [];
var ar_costo = [];

function addAcquisto() {
    ar_acquisto.push(document.getElementById("in_acquisto").value);
    ar_costo.push(document.getElementById("in_costo").value);

    let text = "";
    let totale = 0;
    let media = 0;
    let max = 0;
    let min = 0;

    for (i = 0; i < ar_acquisto.length; i++) {

        text += ar_acquisto[i] + "-" + ar_costo[i] + "<br>";
        totale += ar_costo[i] * 1;

    }
    document.getElementById("div_acquisto").innerHTML = text;
    document.getElementById("sp_totale").innerHTML = totale;
    media += totale / ar_acquisto.length;
    document.getElementById("sp_media").innerHTML = media;
    document.getElementById("sp_max").innerHTML = max;
    max = Math.max.apply(null, ar_costo);
    document.getElementById("sp_min").innerHTML = min;
    min = Math.min.apply(null, ar_costo); 
}






